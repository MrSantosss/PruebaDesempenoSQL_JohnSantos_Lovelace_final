import mysql from 'mysql2/promise';

export const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'Qwe.123*',
  database: 'pd_john_santos_lovelace',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});
