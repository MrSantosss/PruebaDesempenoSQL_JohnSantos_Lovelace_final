import express from 'express';
import fs from 'fs';
import csv from 'csv-parser';
import cors from 'cors';
import { pool } from './db.js';

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cors());
app.use(express.static('.'));

async function query(sql, params) {
  const [rows] = await pool.query(sql, params || []);
  return rows;
}

// Truncate tables in order safe for FKs
async function truncateAll() {
  await pool.query('SET FOREIGN_KEY_CHECKS = 0;');
  await pool.query('TRUNCATE TABLE `Transaction`;');
  await pool.query('TRUNCATE TABLE Invoice;');
  await pool.query('TRUNCATE TABLE Platform;');
  await pool.query('TRUNCATE TABLE Customer;');
  await pool.query('SET FOREIGN_KEY_CHECKS = 1;');
}

async function loadCSVtoDB(filePath, tableName, columns) {
  const rows = [];
  return new Promise((resolve, reject) => {
    fs.createReadStream(filePath)
      .pipe(csv())
      .on('data', (row) => rows.push(row))
      .on('end', async () => {
        try {
          // batch insert using transactions for performance
          await pool.query('START TRANSACTION');
          for (const row of rows) {
            const values = columns.map(col => row[col]);
            await pool.query(
              `INSERT INTO ${tableName} (${columns.join(",")}) VALUES (${columns.map(() => '?').join(",")})`,
              values
            );
          }
          await pool.query('COMMIT');
          console.log(`Inserted ${rows.length} rows into ${tableName}`);
          resolve();
        } catch (err) {
          await pool.query('ROLLBACK');
          reject(err);
        }
      });
  });
}

// Recalculate paid_amount in Invoice from Transaction sums
async function recalcPaidAmounts() {
  await pool.query(`UPDATE Invoice i
    LEFT JOIN (
      SELECT invoice_id, COALESCE(SUM(transaction_amount),0) AS sum_paid
      FROM \`Transaction\`
      GROUP BY invoice_id
    ) t ON i.invoice_id = t.invoice_id
    SET i.paid_amount = COALESCE(t.sum_paid, 0);`);
}

app.get('/load-csv', async (req, res) => {
  try {
    await truncateAll();
    await loadCSVtoDB('./csv/customers.csv', 'Customer', ['customer_id','full_name','identification_number','address','phone','email']);
    await loadCSVtoDB('./csv/platforms.csv', 'Platform', ['platform_id','platform_name']);
    await loadCSVtoDB('./csv/invoices.csv', 'Invoice', ['invoice_id','customer_id','billing_period','billed_amount','paid_amount']);
    await loadCSVtoDB('./csv/transactions.csv', 'Transaction', ['transaction_id','transaction_date','transaction_amount','transaction_status','transaction_type','platform_id','invoice_id']);
    await recalcPaidAmounts();
    res.send('✅ Idempotent load completed and paid_amount recalculated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error in load-csv: ' + err.message);
  }
});

// CRUD Customer
app.post('/customers', async (req, res) => {
  const { full_name, identification_number, address, phone, email } = req.body;
  if (!full_name || !identification_number || !address) {
    return res.status(400).send("Missing required fields");
  }
  try {
    const [result] = await pool.query(
      "INSERT INTO Customer (full_name, identification_number, address, phone, email) VALUES (?, ?, ?, ?, ?)",
      [full_name, identification_number, address, phone, email]
    );
    res.status(201).send({ id: result.insertId, message: "Customer created" });
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.get('/customers', async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM Customer");
    res.json(rows);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.put('/customers/:id', async (req, res) => {
  const { id } = req.params;
  const { full_name, identification_number, address, phone, email } = req.body;
  try {
    await pool.query(
      "UPDATE Customer SET full_name=?, identification_number=?, address=?, phone=?, email=? WHERE customer_id=?",
      [full_name, identification_number, address, phone, email, id]
    );
    res.send("Customer updated");
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.delete('/customers/:id', async (req, res) => {
  const { id } = req.params;
  try {
    // First check if customer has invoices
    const [invoices] = await pool.query(
      "SELECT COUNT(*) as count FROM Invoice WHERE customer_id = ?", 
      [id]
    );
    
    if (invoices[0].count > 0) {
      return res.status(400).json({
        error: "Cannot delete customer",
        message: `Customer has ${invoices[0].count} invoice(s). Delete all invoices first or contact administrator.`,
        invoiceCount: invoices[0].count
      });
    }

    // If no invoices, safe to delete
    const [result] = await pool.query("DELETE FROM Customer WHERE customer_id=?", [id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({
        error: "Customer not found",
        message: "No customer found with the specified ID"
      });
    }

    res.json({
      success: true,
      message: "Customer deleted successfully"
    });
  } catch (err) {
    console.error('Delete customer error:', err);
    res.status(500).json({
      error: "Database error",
      message: err.message
    });
  }
});

// Force delete customer with all related data (USE WITH CAUTION)
app.delete('/customers/:id/force', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('START TRANSACTION');
    
    // Get invoice IDs for this customer
    const [invoices] = await pool.query("SELECT invoice_id FROM Invoice WHERE customer_id = ?", [id]);
    const invoiceIds = invoices.map(inv => inv.invoice_id);
    
    // Delete transactions first (if any invoices exist)
    if (invoiceIds.length > 0) {
      await pool.query("DELETE FROM `Transaction` WHERE invoice_id IN (?)", [invoiceIds]);
      console.log(`Deleted transactions for invoices: ${invoiceIds.join(', ')}`);
    }
    
    // Delete invoices
    const [invoiceResult] = await pool.query("DELETE FROM Invoice WHERE customer_id = ?", [id]);
    
    // Delete customer
    const [customerResult] = await pool.query("DELETE FROM Customer WHERE customer_id = ?", [id]);
    
    if (customerResult.affectedRows === 0) {
      await pool.query('ROLLBACK');
      return res.status(404).json({
        error: "Customer not found",
        message: "No customer found with the specified ID"
      });
    }
    
    await pool.query('COMMIT');
    
    res.json({
      success: true,
      message: "Customer and all related data deleted successfully",
      details: {
        customer_deleted: customerResult.affectedRows,
        invoices_deleted: invoiceResult.affectedRows,
        transactions_deleted: invoiceIds.length
      }
    });
  } catch (err) {
    await pool.query('ROLLBACK');
    console.error('Force delete customer error:', err);
    res.status(500).json({
      error: "Database error",
      message: err.message
    });
  }
});

// ==================== PLATFORM CRUD ====================
app.post('/platforms', async (req, res) => {
  const { platform_name } = req.body;
  if (!platform_name) {
    return res.status(400).json({ error: "Platform name is required" });
  }
  try {
    const [result] = await pool.query(
      "INSERT INTO Platform (platform_name) VALUES (?)",
      [platform_name]
    );
    res.status(201).json({ id: result.insertId, message: "Platform created" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/platforms', async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM Platform ORDER BY platform_name");
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/platforms/:id', async (req, res) => {
  const { id } = req.params;
  const { platform_name } = req.body;
  try {
    const [result] = await pool.query(
      "UPDATE Platform SET platform_name=? WHERE platform_id=?",
      [platform_name, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Platform not found" });
    }
    res.json({ message: "Platform updated" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/platforms/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [transactions] = await pool.query(
      "SELECT COUNT(*) as count FROM `Transaction` WHERE platform_id = ?", 
      [id]
    );
    
    if (transactions[0].count > 0) {
      return res.status(400).json({
        error: "Cannot delete platform",
        message: `Platform has ${transactions[0].count} transaction(s). Delete transactions first.`,
        transactionCount: transactions[0].count
      });
    }

    const [result] = await pool.query("DELETE FROM Platform WHERE platform_id=?", [id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Platform not found" });
    }

    res.json({ message: "Platform deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== INVOICE CRUD ====================
app.post('/invoices', async (req, res) => {
  const { invoice_id, customer_id, billing_period, billed_amount, paid_amount } = req.body;
  if (!invoice_id || !customer_id || !billing_period || !billed_amount) {
    return res.status(400).json({ error: "Missing required fields" });
  }
  try {
    const [result] = await pool.query(
      "INSERT INTO Invoice (invoice_id, customer_id, billing_period, billed_amount, paid_amount) VALUES (?, ?, ?, ?, ?)",
      [invoice_id, customer_id, billing_period, billed_amount, paid_amount || 0]
    );
    res.status(201).json({ message: "Invoice created" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/invoices', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT i.*, c.full_name as customer_name,
             (i.billed_amount - COALESCE(i.paid_amount, 0)) as outstanding_amount
      FROM Invoice i
      JOIN Customer c ON c.customer_id = i.customer_id
      ORDER BY i.billing_period DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/invoices/:id', async (req, res) => {
  const { id } = req.params;
  const { customer_id, billing_period, billed_amount, paid_amount } = req.body;
  try {
    const [result] = await pool.query(
      "UPDATE Invoice SET customer_id=?, billing_period=?, billed_amount=?, paid_amount=? WHERE invoice_id=?",
      [customer_id, billing_period, billed_amount, paid_amount, id]
    );
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Invoice not found" });
    }
    res.json({ message: "Invoice updated" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/invoices/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const [transactions] = await pool.query(
      "SELECT COUNT(*) as count FROM `Transaction` WHERE invoice_id = ?", 
      [id]
    );
    
    if (transactions[0].count > 0) {
      return res.status(400).json({
        error: "Cannot delete invoice",
        message: `Invoice has ${transactions[0].count} transaction(s). Delete transactions first.`,
        transactionCount: transactions[0].count
      });
    }

    const [result] = await pool.query("DELETE FROM Invoice WHERE invoice_id=?", [id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Invoice not found" });
    }

    res.json({ message: "Invoice deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== TRANSACTION CRUD ====================
app.post('/transactions', async (req, res) => {
  const { transaction_id, transaction_date, transaction_amount, transaction_status, transaction_type, platform_id, invoice_id } = req.body;
  if (!transaction_id || !transaction_date || !transaction_amount || !transaction_status || !transaction_type || !platform_id || !invoice_id) {
    return res.status(400).json({ error: "Missing required fields" });
  }
  try {
    await pool.query('START TRANSACTION');
    
    const [result] = await pool.query(
      "INSERT INTO `Transaction` (transaction_id, transaction_date, transaction_amount, transaction_status, transaction_type, platform_id, invoice_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [transaction_id, transaction_date, transaction_amount, transaction_status, transaction_type, platform_id, invoice_id]
    );
    
    // Recalculate paid_amount for the affected invoice
    await pool.query(`
      UPDATE Invoice i
      SET i.paid_amount = (
        SELECT COALESCE(SUM(transaction_amount), 0)
        FROM \`Transaction\` t
        WHERE t.invoice_id = i.invoice_id
      )
      WHERE i.invoice_id = ?
    `, [invoice_id]);
    
    await pool.query('COMMIT');
    res.status(201).json({ message: "Transaction created and invoice updated" });
  } catch (err) {
    await pool.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  }
});

app.get('/transactions', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT t.*, p.platform_name, i.customer_id, c.full_name as customer_name
      FROM \`Transaction\` t
      LEFT JOIN Platform p ON p.platform_id = t.platform_id
      LEFT JOIN Invoice i ON i.invoice_id = t.invoice_id
      LEFT JOIN Customer c ON c.customer_id = i.customer_id
      ORDER BY t.transaction_date DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/transactions/:id', async (req, res) => {
  const { id } = req.params;
  const { transaction_date, transaction_amount, transaction_status, transaction_type, platform_id, invoice_id } = req.body;
  try {
    await pool.query('START TRANSACTION');
    
    // Get the old invoice_id before updating
    const [oldTransaction] = await pool.query("SELECT invoice_id FROM `Transaction` WHERE transaction_id = ?", [id]);
    const oldInvoiceId = oldTransaction[0]?.invoice_id;
    
    const [result] = await pool.query(
      "UPDATE `Transaction` SET transaction_date=?, transaction_amount=?, transaction_status=?, transaction_type=?, platform_id=?, invoice_id=? WHERE transaction_id=?",
      [transaction_date, transaction_amount, transaction_status, transaction_type, platform_id, invoice_id, id]
    );
    
    if (result.affectedRows === 0) {
      await pool.query('ROLLBACK');
      return res.status(404).json({ error: "Transaction not found" });
    }
    
    // Recalculate paid_amount for both old and new invoices
    const invoicesToUpdate = [invoice_id];
    if (oldInvoiceId && oldInvoiceId !== invoice_id) {
      invoicesToUpdate.push(oldInvoiceId);
    }
    
    for (const invId of invoicesToUpdate) {
      await pool.query(`
        UPDATE Invoice i
        SET i.paid_amount = (
          SELECT COALESCE(SUM(transaction_amount), 0)
          FROM \`Transaction\` t
          WHERE t.invoice_id = i.invoice_id
        )
        WHERE i.invoice_id = ?
      `, [invId]);
    }
    
    await pool.query('COMMIT');
    res.json({ message: "Transaction updated and invoices recalculated" });
  } catch (err) {
    await pool.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  }
});

app.delete('/transactions/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('START TRANSACTION');
    
    // Get the invoice_id before deleting
    const [transaction] = await pool.query("SELECT invoice_id FROM `Transaction` WHERE transaction_id = ?", [id]);
    
    if (transaction.length === 0) {
      await pool.query('ROLLBACK');
      return res.status(404).json({ error: "Transaction not found" });
    }
    
    const invoiceId = transaction[0].invoice_id;
    
    const [result] = await pool.query("DELETE FROM `Transaction` WHERE transaction_id=?", [id]);
    
    // Recalculate paid_amount for the affected invoice
    await pool.query(`
      UPDATE Invoice i
      SET i.paid_amount = (
        SELECT COALESCE(SUM(transaction_amount), 0)
        FROM \`Transaction\` t
        WHERE t.invoice_id = i.invoice_id
      )
      WHERE i.invoice_id = ?
    `, [invoiceId]);
    
    await pool.query('COMMIT');
    res.json({ message: "Transaction deleted and invoice updated" });
  } catch (err) {
    await pool.query('ROLLBACK');
    res.status(500).json({ error: err.message });
  }
});

// Reports
app.get('/reports/total-paid-per-customer', async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        c.customer_id,
        c.full_name,
        c.identification_number,
        COALESCE(SUM(t.transaction_amount), 0) AS total_paid
      FROM Customer c
      LEFT JOIN Invoice i ON i.customer_id = c.customer_id
      LEFT JOIN \`Transaction\` t ON t.invoice_id = i.invoice_id
      GROUP BY c.customer_id, c.full_name, c.identification_number
      ORDER BY total_paid DESC;
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.get('/reports/pending-invoices', async (req, res) => {
  try {
    const [invoices] = await pool.query(`
      SELECT
        i.invoice_id,
        i.customer_id,
        c.full_name,
        c.identification_number,
        i.billing_period,
        i.billed_amount,
        i.paid_amount,
        (i.billed_amount - i.paid_amount) AS outstanding_amount
      FROM Invoice i
      JOIN Customer c ON c.customer_id = i.customer_id
      WHERE i.billed_amount > COALESCE(i.paid_amount, 0)
      ORDER BY outstanding_amount DESC;
    `);
    const invoiceIds = invoices.map(r => r.invoice_id);
    let transactions = [];
    if (invoiceIds.length) {
      const [tx] = await pool.query(`
        SELECT
          t.transaction_id,
          t.invoice_id,
          t.transaction_date,
          t.transaction_amount,
          t.transaction_status,
          t.transaction_type,
          p.platform_name
        FROM \`Transaction\` t
        LEFT JOIN Platform p ON p.platform_id = t.platform_id
        WHERE t.invoice_id IN (?)
        ORDER BY t.transaction_date;
      `, [invoiceIds]);
      transactions = tx;
    }
    const result = invoices.map(inv => ({
      ...inv,
      transactions: transactions.filter(t => t.invoice_id === inv.invoice_id)
    }));
    res.json(result);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.get('/reports/transactions-by-platform', async (req, res) => {
  const platform = req.query.platform;
  if (!platform) {
    return res.status(400).send("Query param 'platform' is required, e.g. ?platform=Nequi");
  }
  try {
    const [rows] = await pool.query(`
      SELECT
        t.transaction_id,
        t.transaction_date,
        t.transaction_amount,
        t.transaction_status,
        t.transaction_type,
        p.platform_name,
        t.invoice_id,
        i.customer_id,
        c.full_name,
        c.identification_number
      FROM \`Transaction\` t
      LEFT JOIN Platform p ON p.platform_id = t.platform_id
      LEFT JOIN Invoice i ON i.invoice_id = t.invoice_id
      LEFT JOIN Customer c ON c.customer_id = i.customer_id
      WHERE p.platform_name = ?
      ORDER BY t.transaction_date DESC;
    `, [platform]);
    res.json(rows);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
