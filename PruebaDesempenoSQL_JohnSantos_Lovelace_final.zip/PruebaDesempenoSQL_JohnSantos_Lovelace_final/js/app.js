import { CSVImporter } from './csvImporter.js';
import { CustomerManager } from './customerManager.js';
import { PlatformManager } from './platformManager.js';
import { InvoiceManager } from './invoiceManager.js';
import { TransactionManager } from './transactionManager.js';
import { ReportManager } from './reportManager.js';

class AppManager {
    constructor() {
        this.modules = {};
        this.init();
    }

    init() {
        // Initialize all modules
        this.modules.csvImporter = new CSVImporter();
        this.modules.customerManager = new CustomerManager();
        this.modules.platformManager = new PlatformManager();
        this.modules.invoiceManager = new InvoiceManager();
        this.modules.transactionManager = new TransactionManager();
        this.modules.reportManager = new ReportManager();

        // Set up global references for onclick handlers
        this.setupGlobalReferences();
        
        // Set up tab switching
        this.setupTabSwitching();
        
        // Set up cross-module event listeners
        this.setupCrossModuleEvents();
        
        // Load initial data
        this.loadInitialData();
    }

    setupGlobalReferences() {
        // Make managers globally available for onclick handlers
        window.customerManager = this.modules.customerManager;
        window.platformManager = this.modules.platformManager;
        window.invoiceManager = this.modules.invoiceManager;
        window.transactionManager = this.modules.transactionManager;
    }

    setupTabSwitching() {
        const tabs = document.querySelectorAll('[data-bs-toggle="tab"]');
        tabs.forEach(tab => {
            tab.addEventListener('shown.bs.tab', (event) => {
                const target = event.target.getAttribute('data-bs-target');
                this.handleTabSwitch(target);
            });
        });
    }

    setupCrossModuleEvents() {
        // When transactions are updated, refresh invoices
        window.addEventListener('transactionUpdated', () => {
            this.modules.invoiceManager.fetchData();
        });
    }

    handleTabSwitch(target) {
        switch(target) {
            case '#customers':
                this.modules.customerManager.fetchData();
                break;
            case '#platforms':
                this.modules.platformManager.fetchData();
                break;
            case '#invoices':
                this.modules.invoiceManager.fetchData();
                this.modules.invoiceManager.updateCustomerDropdowns();
                break;
            case '#transactions':
                this.modules.transactionManager.fetchData();
                this.modules.platformManager.fetchData(); // For dropdown
                this.modules.invoiceManager.fetchData(); // For dropdown
                break;
            case '#reports':
                this.modules.platformManager.fetchData(); // For platform selector
                break;
        }
    }

    loadInitialData() {
        // Load customers and platforms on app start
        this.modules.customerManager.fetchData();
        this.modules.platformManager.fetchData();
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    new AppManager();
});
