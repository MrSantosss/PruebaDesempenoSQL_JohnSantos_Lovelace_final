import { CONFIG, showAlert, formatCurrency, formatDateTime, formatDateTimeForInput } from './config.js';

export class TransactionManager {
    constructor() {
        this.form = document.getElementById('transactionForm');
        this.table = document.getElementById('transactionTable');
        this.data = [];
        this.init();
    }

    init() {
        if (this.form) {
            this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        }
        
        window.addEventListener('dataRefreshed', () => this.fetchData());
    }

    async fetchData() {
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.TRANSACTIONS}`);
            this.data = await response.json();
            this.renderTable();
        } catch (error) {
            showAlert('❌ Error loading transactions', 'danger');
            console.error('Error fetching transactions:', error);
        }
    }

    renderTable() {
        if (!this.table) return;

        this.table.innerHTML = this.data.map(transaction => `
            <tr>
                <td>${transaction.transaction_id}</td>
                <td>${formatDateTime(transaction.transaction_date)}</td>
                <td>${formatCurrency(transaction.transaction_amount)}</td>
                <td>
                    <span class="badge bg-${this.getStatusBadgeClass(transaction.transaction_status)}">
                        ${transaction.transaction_status}
                    </span>
                </td>
                <td>${transaction.transaction_type}</td>
                <td>${transaction.platform_name || 'N/A'}</td>
                <td>${transaction.invoice_id} - ${transaction.customer_name || 'N/A'}</td>
                <td>
                    <button onclick="transactionManager.edit('${transaction.transaction_id}')" class="btn btn-warning btn-sm">✏️ Edit</button>
                    <button onclick="transactionManager.delete('${transaction.transaction_id}')" class="btn btn-danger btn-sm">🗑️ Delete</button>
                </td>
            </tr>
        `).join('');
    }

    getStatusBadgeClass(status) {
        switch(status) {
            case 'Completed': return 'success';
            case 'Pending': return 'warning';
            case 'Failed': return 'danger';
            default: return 'secondary';
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        const editId = document.getElementById("edit_transaction_id").value;
        const transactionData = {
            transaction_id: document.getElementById("transaction_id").value,
            transaction_date: document.getElementById("transaction_date").value,
            transaction_amount: parseFloat(document.getElementById("transaction_amount").value),
            transaction_status: document.getElementById("transaction_status").value,
            transaction_type: document.getElementById("transaction_type").value,
            platform_id: document.getElementById("transaction_platform_id").value,
            invoice_id: document.getElementById("transaction_invoice_id").value
        };

        try {
            const url = editId ? 
                `${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.TRANSACTIONS}/${editId}` : 
                `${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.TRANSACTIONS}`;
            
            const method = editId ? "PUT" : "POST";
            
            const response = await fetch(url, {
                method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(transactionData)
            });

            if (response.ok) {
                showAlert(editId ? '✅ Transaction updated successfully' : '✅ Transaction created successfully', 'success');
                e.target.reset();
                this.fetchData();
                
                // Notify invoice manager to refresh (paid amounts might have changed)
                window.dispatchEvent(new CustomEvent('transactionUpdated'));
            } else {
                const error = await response.json();
                showAlert(`❌ Error: ${error.error}`, 'danger');
            }
        } catch (error) {
            showAlert(`❌ Network error: ${error.message}`, 'danger');
        }
    }

    edit(id) {
        const transaction = this.data.find(t => t.transaction_id === id);
        if (transaction) {
            document.getElementById("edit_transaction_id").value = transaction.transaction_id;
            document.getElementById("transaction_id").value = transaction.transaction_id;
            document.getElementById("transaction_date").value = formatDateTimeForInput(transaction.transaction_date);
            document.getElementById("transaction_amount").value = transaction.transaction_amount;
            document.getElementById("transaction_status").value = transaction.transaction_status;
            document.getElementById("transaction_type").value = transaction.transaction_type;
            document.getElementById("transaction_platform_id").value = transaction.platform_id;
            document.getElementById("transaction_invoice_id").value = transaction.invoice_id;
        }
    }

    async delete(id) {
        if (!confirm("Are you sure you want to delete this transaction?")) {
            return;
        }
        
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.TRANSACTIONS}/${id}`, { 
                method: "DELETE" 
            });
            const result = await response.json();
            
            if (response.ok) {
                showAlert(`✅ ${result.message}`, 'success');
                // Notify invoice manager to refresh (paid amounts might have changed)
                window.dispatchEvent(new CustomEvent('transactionUpdated'));
            } else {
                showAlert(`❌ Error: ${result.message}`, 'danger');
            }
        } catch (error) {
            showAlert(`❌ Network error: ${error.message}`, 'danger');
        }
        
        this.fetchData();
    }
}
