// Configuration and constants
export const CONFIG = {
    BASE_URL: "http://localhost:3000",
    ENDPOINTS: {
        CUSTOMERS: "/customers",
        PLATFORMS: "/platforms", 
        INVOICES: "/invoices",
        TRANSACTIONS: "/transactions",
        LOAD_CSV: "/load-csv",
        REPORTS: {
            TOTAL_PAID: "/reports/total-paid-per-customer",
            PENDING_INVOICES: "/reports/pending-invoices", 
            TRANSACTIONS_BY_PLATFORM: "/reports/transactions-by-platform"
        }
    }
};

// Utility functions
export function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
    document.body.insertBefore(alertDiv, document.body.firstChild);
    setTimeout(() => alertDiv.remove(), 5000);
}

export function formatCurrency(amount) {
    return '$' + (amount || 0).toLocaleString();
}

export function formatDateTime(dateString) {
    return new Date(dateString).toLocaleString();
}

export function formatDateTimeForInput(dateString) {
    const date = new Date(dateString);
    return date.getFullYear() + '-' + 
           String(date.getMonth() + 1).padStart(2, '0') + '-' + 
           String(date.getDate()).padStart(2, '0') + 'T' + 
           String(date.getHours()).padStart(2, '0') + ':' + 
           String(date.getMinutes()).padStart(2, '0');
}
