import { CONFIG, showAlert } from './config.js';

export class CSVImporter {
    constructor() {
        this.importBtn = document.getElementById('importCsvBtn');
        this.statusDiv = document.getElementById('importStatus');
        this.init();
    }

    init() {
        if (this.importBtn) {
            this.importBtn.addEventListener('click', () => this.importCSVData());
        }
    }

    async importCSVData() {
        this.setLoadingState(true);
        
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.LOAD_CSV}`);
            const result = await response.text();
            
            if (response.ok) {
                this.showStatus(result, 'success');
                showAlert('✅ CSV data imported successfully!', 'success');
                
                // Notify other modules to refresh their data
                this.notifyDataRefresh();
            } else {
                this.showStatus(`Error: ${result}`, 'danger');
                showAlert('❌ Failed to import CSV data', 'danger');
            }
        } catch (error) {
            this.showStatus(`Network error: ${error.message}`, 'danger');
            showAlert('❌ Network error during import', 'danger');
        } finally {
            this.setLoadingState(false);
        }
    }

    setLoadingState(loading) {
        if (this.importBtn) {
            this.importBtn.disabled = loading;
            this.importBtn.innerHTML = loading ? '⏳ Importing...' : '🚀 Import CSV Data';
        }
        
        if (loading && this.statusDiv) {
            this.statusDiv.innerHTML = '<div class="alert alert-info">Loading CSV data...</div>';
        }
    }

    showStatus(message, type) {
        if (this.statusDiv) {
            this.statusDiv.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
        }
    }

    notifyDataRefresh() {
        // Dispatch custom event to notify other modules
        window.dispatchEvent(new CustomEvent('dataRefreshed'));
    }
}
