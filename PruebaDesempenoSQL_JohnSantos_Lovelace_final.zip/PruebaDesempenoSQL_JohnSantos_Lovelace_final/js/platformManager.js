import { CONFIG, showAlert } from './config.js';

export class PlatformManager {
    constructor() {
        this.form = document.getElementById('platformForm');
        this.table = document.getElementById('platformTable');
        this.data = [];
        this.init();
    }

    init() {
        if (this.form) {
            this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        }
        
        window.addEventListener('dataRefreshed', () => this.fetchData());
    }

    async fetchData() {
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.PLATFORMS}`);
            this.data = await response.json();
            this.renderTable();
            this.updateDropdowns();
        } catch (error) {
            showAlert('❌ Error loading platforms', 'danger');
            console.error('Error fetching platforms:', error);
        }
    }

    renderTable() {
        if (!this.table) return;

        this.table.innerHTML = this.data.map(platform => `
            <tr>
                <td>${platform.platform_id}</td>
                <td>${platform.platform_name}</td>
                <td>
                    <button onclick="platformManager.edit(${platform.platform_id})" class="btn btn-warning btn-sm">✏️ Edit</button>
                    <button onclick="platformManager.delete(${platform.platform_id})" class="btn btn-danger btn-sm">🗑️ Delete</button>
                </td>
            </tr>
        `).join('');
    }

    updateDropdowns() {
        // Update transaction platform dropdown (uses platform_id)
        const transactionSelect = document.getElementById('transaction_platform_id');
        if (transactionSelect) {
            const currentValue = transactionSelect.value;
            transactionSelect.innerHTML = '<option value="">Select Platform</option>' +
                this.data.map(p => `<option value="${p.platform_id}">${p.platform_name}</option>`).join('');
            if (currentValue) transactionSelect.value = currentValue;
        }
        
        // Update reports platform dropdown (uses platform_name)
        const reportSelect = document.getElementById('platformSelect');
        if (reportSelect) {
            const currentValue = reportSelect.value;
            reportSelect.innerHTML = '<option value="">Select Platform</option>' +
                this.data.map(p => `<option value="${p.platform_name}">${p.platform_name}</option>`).join('');
            if (currentValue) reportSelect.value = currentValue;
        }
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        const id = document.getElementById("platform_id").value;
        const platformData = {
            platform_name: document.getElementById("platform_name").value
        };

        try {
            const url = id ? 
                `${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.PLATFORMS}/${id}` : 
                `${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.PLATFORMS}`;
            
            const method = id ? "PUT" : "POST";
            
            const response = await fetch(url, {
                method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(platformData)
            });

            if (response.ok) {
                showAlert(id ? '✅ Platform updated successfully' : '✅ Platform created successfully', 'success');
                e.target.reset();
                this.fetchData();
            } else {
                const error = await response.json();
                showAlert(`❌ Error: ${error.error}`, 'danger');
            }
        } catch (error) {
            showAlert(`❌ Network error: ${error.message}`, 'danger');
        }
    }

    edit(id) {
        const platform = this.data.find(p => p.platform_id === id);
        if (platform) {
            document.getElementById("platform_id").value = platform.platform_id;
            document.getElementById("platform_name").value = platform.platform_name;
        }
    }

    async delete(id) {
        if (!confirm("Are you sure you want to delete this platform?")) {
            return;
        }
        
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.PLATFORMS}/${id}`, { 
                method: "DELETE" 
            });
            const result = await response.json();
            
            if (response.ok) {
                showAlert(`✅ ${result.message}`, 'success');
            } else {
                showAlert(`❌ Error: ${result.message}`, 'danger');
            }
        } catch (error) {
            showAlert(`❌ Network error: ${error.message}`, 'danger');
        }
        
        this.fetchData();
    }

    // Getter for external access to platform data
    getData() {
        return this.data;
    }
}
