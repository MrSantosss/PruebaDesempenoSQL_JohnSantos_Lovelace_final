import { CONFIG, showAlert, formatCurrency } from './config.js';

export class ReportManager {
    constructor() {
        this.resultsDiv = document.getElementById('reportResults');
        this.init();
    }

    init() {
        // Set up report buttons
        const reportButtons = document.querySelectorAll('[onclick*="loadReport"]');
        reportButtons.forEach(button => {
            const reportType = button.getAttribute('onclick').match(/'([^']+)'/)[1];
            button.removeAttribute('onclick');
            button.addEventListener('click', () => this.loadReport(reportType));
        });
    }

    async loadReport(type) {
        if (!this.resultsDiv) return;

        this.resultsDiv.innerHTML = '<div class="alert alert-info">Loading report...</div>';
        
        try {
            const url = this.getReportUrl(type);
            if (!url) return;

            const response = await fetch(url);
            const data = await response.json();
            
            if (response.ok) {
                this.displayReportData(data, type);
            } else {
                this.resultsDiv.innerHTML = `<div class="alert alert-danger">Error loading report: ${data.message || 'Unknown error'}</div>`;
            }
        } catch (error) {
            this.resultsDiv.innerHTML = `<div class="alert alert-danger">Network error: ${error.message}</div>`;
        }
    }

    getReportUrl(type) {
        const baseUrl = CONFIG.BASE_URL;
        
        switch(type) {
            case 'total-paid':
                return `${baseUrl}${CONFIG.ENDPOINTS.REPORTS.TOTAL_PAID}`;
            case 'pending-invoices':
                return `${baseUrl}${CONFIG.ENDPOINTS.REPORTS.PENDING_INVOICES}`;
            case 'transactions-by-platform':
                const platform = document.getElementById('platformSelect')?.value;
                if (!platform) {
                    showAlert('Please select a platform first', 'warning');
                    return null;
                }
                return `${baseUrl}${CONFIG.ENDPOINTS.REPORTS.TRANSACTIONS_BY_PLATFORM}?platform=${platform}`;
            default:
                showAlert('Unknown report type', 'danger');
                return null;
        }
    }

    displayReportData(data, type) {
        if (!this.resultsDiv) return;

        let html = '<div class="card"><div class="card-body">';
        
        if (data.length === 0) {
            html += '<div class="alert alert-warning">No data found for this report.</div>';
        } else {
            html += '<div class="table-responsive"><table class="table table-striped">';
            
            // Create table headers
            const headers = Object.keys(data[0]);
            html += '<thead class="table-dark"><tr>';
            headers.forEach(header => {
                html += `<th>${this.formatHeaderName(header)}</th>`;
            });
            html += '</tr></thead><tbody>';
            
            // Create table rows
            data.forEach(row => {
                html += '<tr>';
                headers.forEach(header => {
                    let value = row[header];
                    if (typeof value === 'number' && header.includes('amount')) {
                        value = formatCurrency(value);
                    }
                    html += `<td>${value || ''}</td>`;
                });
                html += '</tr>';
            });
            
            html += '</tbody></table></div>';
        }
        
        html += '</div></div>';
        this.resultsDiv.innerHTML = html;
    }

    formatHeaderName(header) {
        return header.replace(/_/g, ' ')
                    .split(' ')
                    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
                    .join(' ');
    }
}
