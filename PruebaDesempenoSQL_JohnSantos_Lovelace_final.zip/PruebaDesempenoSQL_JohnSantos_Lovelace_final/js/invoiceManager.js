import { CONFIG, showAlert, formatCurrency } from './config.js';

export class InvoiceManager {
    constructor() {
        this.form = document.getElementById('invoiceForm');
        this.table = document.getElementById('invoiceTable');
        this.data = [];
        this.init();
    }

    init() {
        if (this.form) {
            this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        }
        
        window.addEventListener('dataRefreshed', () => this.fetchData());
    }

    async fetchData() {
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.INVOICES}`);
            this.data = await response.json();
            this.renderTable();
            this.updateDropdowns();
        } catch (error) {
            showAlert('❌ Error loading invoices', 'danger');
            console.error('Error fetching invoices:', error);
        }
    }

    async updateCustomerDropdowns() {
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.CUSTOMERS}`);
            const customers = await response.json();
            
            const select = document.getElementById('invoice_customer_id');
            if (select) {
                const currentValue = select.value;
                select.innerHTML = '<option value="">Select Customer</option>' +
                    customers.map(c => `<option value="${c.customer_id}">${c.full_name} (${c.identification_number})</option>`).join('');
                if (currentValue) select.value = currentValue;
            }
        } catch (error) {
            console.error('Error updating customer dropdowns:', error);
        }
    }

    updateDropdowns() {
        // Update transaction invoice dropdown
        const select = document.getElementById('transaction_invoice_id');
        if (select) {
            const currentValue = select.value;
            select.innerHTML = '<option value="">Select Invoice</option>' +
                this.data.map(i => `<option value="${i.invoice_id}">${i.invoice_id} - ${i.customer_name}</option>`).join('');
            if (currentValue) select.value = currentValue;
        }
    }

    renderTable() {
        if (!this.table) return;

        this.table.innerHTML = this.data.map(invoice => `
            <tr>
                <td>${invoice.invoice_id}</td>
                <td>${invoice.customer_name} (${invoice.customer_id})</td>
                <td>${invoice.billing_period}</td>
                <td>${formatCurrency(invoice.billed_amount)}</td>
                <td>${formatCurrency(invoice.paid_amount)}</td>
                <td>${formatCurrency(invoice.outstanding_amount)}</td>
                <td>
                    <button onclick="invoiceManager.edit('${invoice.invoice_id}')" class="btn btn-warning btn-sm">✏️ Edit</button>
                    <button onclick="invoiceManager.delete('${invoice.invoice_id}')" class="btn btn-danger btn-sm">🗑️ Delete</button>
                </td>
            </tr>
        `).join('');
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        const editId = document.getElementById("edit_invoice_id").value;
        const invoiceData = {
            invoice_id: document.getElementById("invoice_id").value,
            customer_id: document.getElementById("invoice_customer_id").value,
            billing_period: document.getElementById("billing_period").value,
            billed_amount: parseFloat(document.getElementById("billed_amount").value),
            paid_amount: parseFloat(document.getElementById("paid_amount").value) || 0
        };

        try {
            const url = editId ? 
                `${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.INVOICES}/${editId}` : 
                `${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.INVOICES}`;
            
            const method = editId ? "PUT" : "POST";
            
            const response = await fetch(url, {
                method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(invoiceData)
            });

            if (response.ok) {
                showAlert(editId ? '✅ Invoice updated successfully' : '✅ Invoice created successfully', 'success');
                e.target.reset();
                this.fetchData();
            } else {
                const error = await response.json();
                showAlert(`❌ Error: ${error.error}`, 'danger');
            }
        } catch (error) {
            showAlert(`❌ Network error: ${error.message}`, 'danger');
        }
    }

    edit(id) {
        const invoice = this.data.find(i => i.invoice_id === id);
        if (invoice) {
            document.getElementById("edit_invoice_id").value = invoice.invoice_id;
            document.getElementById("invoice_id").value = invoice.invoice_id;
            document.getElementById("invoice_customer_id").value = invoice.customer_id;
            document.getElementById("billing_period").value = invoice.billing_period;
            document.getElementById("billed_amount").value = invoice.billed_amount;
            document.getElementById("paid_amount").value = invoice.paid_amount || 0;
        }
    }

    async delete(id) {
        if (!confirm("Are you sure you want to delete this invoice?")) {
            return;
        }
        
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.INVOICES}/${id}`, { 
                method: "DELETE" 
            });
            const result = await response.json();
            
            if (response.ok) {
                showAlert(`✅ ${result.message}`, 'success');
            } else {
                showAlert(`❌ Error: ${result.message}`, 'danger');
            }
        } catch (error) {
            showAlert(`❌ Network error: ${error.message}`, 'danger');
        }
        
        this.fetchData();
    }

    // Getter for external access to invoice data
    getData() {
        return this.data;
    }
}
