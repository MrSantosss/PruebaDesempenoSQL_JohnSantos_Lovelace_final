import { CONFIG, showAlert } from './config.js';

export class CustomerManager {
    constructor() {
        this.form = document.getElementById('customerForm');
        this.table = document.getElementById('customerTable');
        this.init();
    }

    init() {
        if (this.form) {
            this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        }
        
        // Listen for data refresh events
        window.addEventListener('dataRefreshed', () => this.fetchData());
    }

    async fetchData() {
        if (!this.table) return;

        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.CUSTOMERS}`);
            const data = await response.json();
            this.renderTable(data);
        } catch (error) {
            showAlert('❌ Error loading customers', 'danger');
            console.error('Error fetching customers:', error);
        }
    }

    renderTable(customers) {
        if (!this.table) return;

        this.table.innerHTML = customers.map(customer => `
            <tr>
                <td>${customer.customer_id}</td>
                <td>${customer.full_name}</td>
                <td>${customer.identification_number}</td>
                <td>${customer.address}</td>
                <td>${customer.phone || ""}</td>
                <td>${customer.email || ""}</td>
                <td>
                    <button onclick="customerManager.edit(${customer.customer_id})" class="btn btn-warning btn-sm">✏️ Edit</button>
                    <button onclick="customerManager.delete(${customer.customer_id})" class="btn btn-danger btn-sm">🗑️ Delete</button>
                </td>
            </tr>
        `).join('');
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const id = document.getElementById("customer_id").value;
        
        const customerData = {
            full_name: formData.get('full_name') || document.getElementById("full_name").value,
            identification_number: formData.get('identification_number') || document.getElementById("identification_number").value,
            address: formData.get('address') || document.getElementById("address").value,
            phone: formData.get('phone') || document.getElementById("phone").value,
            email: formData.get('email') || document.getElementById("email").value
        };

        try {
            const url = id ? 
                `${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.CUSTOMERS}/${id}` : 
                `${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.CUSTOMERS}`;
            
            const method = id ? "PUT" : "POST";
            
            const response = await fetch(url, {
                method,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(customerData)
            });

            if (response.ok) {
                showAlert(id ? '✅ Customer updated successfully' : '✅ Customer created successfully', 'success');
                e.target.reset();
                this.fetchData();
            } else {
                const error = await response.text();
                showAlert(`❌ Error: ${error}`, 'danger');
            }
        } catch (error) {
            showAlert(`❌ Network error: ${error.message}`, 'danger');
        }
    }

    async edit(id) {
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.CUSTOMERS}`);
            const customers = await response.json();
            const customer = customers.find(c => c.customer_id === id);
            
            if (customer) {
                document.getElementById("customer_id").value = customer.customer_id;
                document.getElementById("full_name").value = customer.full_name;
                document.getElementById("identification_number").value = customer.identification_number;
                document.getElementById("address").value = customer.address;
                document.getElementById("phone").value = customer.phone || '';
                document.getElementById("email").value = customer.email || '';
            }
        } catch (error) {
            showAlert('❌ Error loading customer data', 'danger');
        }
    }

    async delete(id) {
        if (!confirm("Are you sure you want to delete this customer?")) {
            return;
        }
        
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.CUSTOMERS}/${id}`, { 
                method: "DELETE" 
            });
            const result = await response.json();
            
            if (!response.ok) {
                if (response.status === 400 && result.invoiceCount) {
                    const forceDelete = confirm(
                        `${result.message}\n\nDo you want to FORCE DELETE this customer and ALL their invoices/transactions?\n\n⚠️ WARNING: This action cannot be undone!`
                    );
                    
                    if (forceDelete) {
                        await this.forceDelete(id);
                    }
                } else {
                    showAlert(`❌ Error: ${result.message}`, 'danger');
                }
            } else {
                showAlert(`✅ ${result.message}`, 'success');
            }
        } catch (error) {
            showAlert(`❌ Network error: ${error.message}`, 'danger');
        }
        
        this.fetchData();
    }

    async forceDelete(id) {
        try {
            const response = await fetch(`${CONFIG.BASE_URL}${CONFIG.ENDPOINTS.CUSTOMERS}/${id}/force`, { 
                method: "DELETE" 
            });
            const result = await response.json();
            
            if (response.ok) {
                showAlert(`✅ ${result.message}`, 'success');
            } else {
                showAlert(`❌ Error: ${result.message}`, 'danger');
            }
        } catch (error) {
            showAlert(`❌ Network error: ${error.message}`, 'danger');
        }
    }
}
