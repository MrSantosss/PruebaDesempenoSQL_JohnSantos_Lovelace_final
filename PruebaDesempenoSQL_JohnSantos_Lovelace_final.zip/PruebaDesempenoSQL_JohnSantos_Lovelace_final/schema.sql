-- Schema DDL for Prueba de Desempeño (John Santos - Lovelace)
CREATE DATABASE IF NOT EXISTS pd_john_santos_lovelace;
USE pd_john_santos_lovelace;

CREATE TABLE IF NOT EXISTS Customer (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    identification_number VARCHAR(50) NOT NULL UNIQUE,
    address TEXT NOT NULL,
    phone VARCHAR(30),
    email VARCHAR(100) UNIQUE
);

CREATE TABLE IF NOT EXISTS Platform (
    platform_id INT PRIMARY KEY AUTO_INCREMENT,
    platform_name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Invoice (
    invoice_id VARCHAR(50) PRIMARY KEY,
    customer_id INT NOT NULL,
    billing_period DATE NOT NULL,
    billed_amount DECIMAL(12,2) NOT NULL,
    paid_amount DECIMAL(12,2) DEFAULT 0,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

CREATE TABLE IF NOT EXISTS `Transaction` (
    transaction_id VARCHAR(50) PRIMARY KEY,
    transaction_date DATETIME NOT NULL,
    transaction_amount DECIMAL(12,2) NOT NULL,
    transaction_status VARCHAR(50) NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    platform_id INT NOT NULL,
    invoice_id VARCHAR(50) NOT NULL,
    FOREIGN KEY (platform_id) REFERENCES Platform(platform_id),
    FOREIGN KEY (invoice_id) REFERENCES Invoice(invoice_id)
);
