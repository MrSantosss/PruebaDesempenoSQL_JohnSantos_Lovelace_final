# Performance Test - SQL Database Module
**Student:** John Santos  
**Clan:** Lovelace  
**Email:** jhonalejandrosantosmurillo@gmail.com  
**Date:** August 2025

## Project Description
Payment transaction management system developed in Node.js with Express and MySQL. Implements database normalization (1NF → 3NF), massive CSV data loading, complete CRUD operations, and advanced reports with complex SQL queries.

## Project Structure
```
📁 PruebaDesempenoSQL_JohnSantos_Lovelace_final/
├── 📄 server.js                          # Express server with complete REST API
├── 📄 db.js                             # MySQL connection pool
├── 📄 schema.sql                        # DDL - Database structure definition
├── 📄 package.json                      # Node.js dependencies
├── 📄 package-lock.json                 # Dependency lock file
├── 📄 index.html                        # Web dashboard with Bootstrap 5
├── 📄 PruebaDesempenoSQL.postman_collection.json  # Postman collection
├── 📄 README.md                         # Project documentation
├── 📁 csv/                              # Normalized CSV files
│   ├── customers.csv                    # 100 unique customers
│   ├── platforms.csv                    # 2 platforms (Nequi, Daviplata)
│   ├── invoices.csv                     # 100 invoices
│   └── transactions.csv                 # 100 transactions
├── 📁 js/                               # Frontend JavaScript modules
│   ├── app.js                           # Main orchestrator
│   ├── config.js                        # Central configurations
│   ├── csvImporter.js                   # CSV file importer
│   ├── customerManager.js               # Customer management
│   ├── invoiceManager.js                # Invoice management
│   ├── platformManager.js               # Platform management
│   ├── reportManager.js                 # Report generation
│   └── transactionManager.js            # Transaction management
└── 📁 node_modules/                     # Dependencies (auto-generated)
```

## Setup and Installation

### Prerequisites
- Node.js (v16 or higher)
- MySQL Server (v8.0 or higher)
- Git

### Installation Steps
1. **Clone/Download the project**
   ```bash
   cd PruebaDesempenoSQL_JohnSantos_Lovelace_final
   ```

2. **Configure database**
   - Edit `db.js` and update MySQL credentials:
   ```javascript
   host: 'localhost',
   user: 'root',
   password: 'YOUR_PASSWORD_HERE',
   database: 'pd_john_santos_lovelace'
   ```

3. **Create database and tables**
   ```bash
   mysql -u root -p < schema.sql
   ```

4. **Install dependencies**
   ```bash
   npm install
   ```

5. **Start server**
   ```bash
   npm start
   ```
   Server will be available at: http://localhost:3000

6. **Load CSV data (optional)**
   - Access: http://localhost:3000/load-csv
   - Or use "Load CSV" button in web interface

## Implemented Features

### 🗃️ **Database Normalization**
- **First Normal Form (1NF)**: Elimination of repeating groups
- **Second Normal Form (2NF)**: Elimination of partial dependencies  
- **Third Normal Form (3NF)**: Elimination of transitive dependencies

**Resulting tables:**
- `Customer` - Client information
- `Platform` - Payment platforms (Nequi, Daviplata)
- `Invoice` - Invoices with billing periods
- `Transaction` - Individual transactions with status

### 🔄 **Massive Data Loading**
- **Endpoint**: `GET /load-csv`
- **Features**: 
  - Idempotent loading (can be executed multiple times)
  - Safe truncation with FK constraint handling
  - Automatic recalculation of paid amounts
  - ACID transactions for integrity

### 📊 **Complete CRUD Operations**
#### Customers
- `POST /customers` - Create customer
- `GET /customers` - List all customers
- `PUT /customers/:id` - Update customer
- `DELETE /customers/:id` - Delete customer (with FK validation)

#### Platforms  
- `POST /platforms` - Create platform
- `GET /platforms` - List platforms

#### Invoices
- `POST /invoices` - Create invoice
- `GET /invoices` - List invoices
- `PUT /invoices/:id` - Update invoice
- `DELETE /invoices/:id` - Delete invoice

#### Transactions
- `POST /transactions` - Create transaction
- `GET /transactions` - List transactions  
- `PUT /transactions/:id` - Update transaction
- `DELETE /transactions/:id` - Delete transaction

### 📈 **Advanced Reports with Complex SQL Queries**

#### 1. Total Paid per Customer
- **Endpoint**: `GET /reports/total-paid-per-customer`
- **SQL Query**: LEFT JOIN between Customer → Invoice → Transaction
- **Functionality**: Total payment sum per customer ordered descending

#### 2. Pending Invoices with Transaction Details  
- **Endpoint**: `GET /reports/pending-invoices`
- **SQL Query**: Multiple JOINs with subqueries
- **Functionality**: Invoices with pending balance + associated transactions

#### 3. Transactions by Platform
- **Endpoint**: `GET /reports/transactions-by-platform?platform=Nequi`
- **SQL Query**: JOIN with parameterized filter
- **Functionality**: Complete transaction history by platform

### 🎨 **Interactive Web Dashboard**
- **Technology**: Bootstrap 5 + JavaScript ES6 Modules
- **Features**:
  - Tabular interface with intuitive navigation
  - Complete CRUD for all entities
  - Real-time report visualization
  - CSV import from web interface
  - Modular architecture with 8 JavaScript components

## Technical Architecture

### Backend (Node.js + Express)
- **MySQL connection pool** with error handling
- **Referential integrity validations** 
- **ACID transactions** for critical operations
- **FK constraint handling** with intelligent deletion
- **REST API** following HTTP conventions

### Frontend (Vanilla JavaScript)
- **Modular architecture** with separation of concerns
- **Event system** for inter-module communication
- **Centralized management** of configurations and utilities
- **Responsive interface** adaptable to different screens

### Database (MySQL)
- **Optimized indexes** on foreign keys
- **Referential integrity constraints**
- **Appropriate data types** for each field
- **English nomenclature** following standards

## Implemented Use Cases

### 📝 **Customer Management**
- Registration of new customers with validations
- Personal information updates
- Deletion with dependency verification
- Transaction history queries

### 💳 **Transaction Processing**
- Transaction registration with multiple statuses
- Association with invoices and platforms  
- Automatic calculation of paid balances
- Complete payment traceability

### 📊 **Analysis and Reports**
- Identification of top paying customers
- Pending invoice tracking
- Payment platform analysis
- Collection performance metrics

## Requirements Validation

### ✅ **Evaluation Criteria Met**
- [x] **1NF → 3NF Normalization**: 4 normalized tables without dependencies
- [x] **DDL in English**: `schema.sql` with PKs, FKs and constraints  
- [x] **CSV conversion and loading**: 100 transaction records processed
- [x] **Massive loading endpoint**: `GET /load-csv` idempotent
- [x] **Customer CRUD**: Complete operations with validations
- [x] **Web dashboard**: Functional Bootstrap interface
- [x] **3 advanced queries**: Reports with complex JOINs  
- [x] **Postman collection**: Documented and tested endpoints
- [x] **Technical README**: Complete installation instructions
- [x] **Structured delivery**: Project ready for evaluation

### 🚀 **Additional Features (Added Value)**
- [x] **Complete CRUD for all entities** (not just Customer)
- [x] **Professional modular architecture** (8 JavaScript modules)
- [x] **Advanced FK constraint handling** with intelligent deletion
- [x] **Frontend event system** for component communication  
- [x] **Automatic amount recalculation** for data consistency
- [x] **Optimized connection pool** for better performance
- [x] **Integrity validations** in backend and frontend
- [x] **Complete web interface** beyond basic dashboard

## Technical Notes

### Performance Considerations
- MySQL connection pool configured for high concurrency
- Optimized indexes on foreign keys for efficient JOINs
- Batch transactions for massive data loading
- Frontend lazy loading for better UX

### Security and Validations  
- Input sanitization on all endpoints
- Data type and range validation
- SQL error handling with friendly messages
- Referential integrity verification before deletions

### Maintainability
- Modular code with separation of responsibilities
- Descriptive naming and explanatory comments  
- Centralized configurations for easy modification
- Detailed logging for debugging and monitoring

## Author and Contact
**John Santos**  
**Clan:** Lovelace  
**Email:** jhonalejandrosantosmurillo@gmail.com  
**Project:** Performance Test - SQL Database Module  
**Date:** August 2025
